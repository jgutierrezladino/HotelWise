let variable = "Home";
console.log(variable);

document.getElementById("txt00").innerHTML = "Rol a Desarrollar";
